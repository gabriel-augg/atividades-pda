


function verificar() {
    var resultado = document.getElementById("resultado")
    var salario = document.getElementById("butao").valueAsNumber
    if (salario < 280) {
        salario = salario + (salario * 0.2)
        resultado.innerHTML = salario
    } else if (salario > 280 && salario < 700) {
        salario += salario * 0.15
        resultado.innerHTML = salario
    } else if (salario > 700 && salario < 1500) {
        salario += salario * 0.1
        resultado.innerHTML = salario
    } else if ( salario > 1500) {
        salario += salario * 0.05
        resultado.innerHTML = salario
    }
}